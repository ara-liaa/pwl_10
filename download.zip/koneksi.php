<?php
$host = "sql302.infinityfree.com";
$user = "if0_42376717";
$pass = "voXBmvxmKN";
$db   = "if0_42376717_db_wl";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>